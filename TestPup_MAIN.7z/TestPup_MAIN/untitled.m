data = zeros(100,2);
for i = 1:10
    for j = 1:10
        data(10*(i - 1)+j,:) = [i,j];
    end
end